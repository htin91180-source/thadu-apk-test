Stage 3.1 — Generator Logic
- Keeps the Builder UI.
- HTML file -> generated Android project ZIP.
- ZIP file -> contents copied into Android assets.
- App Name / Package / Version applied.
- Native FileProvider + ACTION_SEND bridge included.
- Output is an Android project ZIP, not an APK yet.
- JSZip is loaded from jsDelivr, so internet is required when generating.
