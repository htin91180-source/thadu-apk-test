Stage 4 — Cloud APK Build

Purpose:
Generate an Android project ZIP that can be built remotely from a phone
without installing Android Studio/SDK locally.

Generated project includes:
- .github/workflows/build-apk.yml
- Java 17 setup
- Gradle 8.7
- `gradle :app:assembleDebug`
- APK artifact upload

Phone workflow:
1. Generate Android Project ZIP.
2. Upload/extract it into a GitHub repository.
3. Open GitHub Actions.
4. Select "Build Android APK".
5. Run workflow.
6. Download the generated debug APK from the workflow artifacts.

Important:
- This produces a DEBUG APK.
- Release signing/keystore is a separate stage.
- The cloud build workflow does not execute inside the HTML page itself.


STAGE 4.1 FIX: Kotlin duplicate-class build error fixed by aligning Kotlin stdlib to 1.8.22 and excluding legacy kotlin-stdlib-jdk8.
