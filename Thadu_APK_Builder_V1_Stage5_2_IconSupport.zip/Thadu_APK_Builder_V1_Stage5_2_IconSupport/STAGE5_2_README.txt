Thadu APK Builder V1 - Stage 5.2

New: real launcher App Icon support.
- Choose PNG/JPG in App Icon.
- Builder copies it into app/src/main/res/drawable/app_icon.*
- Generated AndroidManifest references @drawable/app_icon when selected.
- Native Print/PDF, Native Text Share, and Native JPG Share are preserved.
- Existing Builder UI and HTML/ZIP payload flow are preserved.
