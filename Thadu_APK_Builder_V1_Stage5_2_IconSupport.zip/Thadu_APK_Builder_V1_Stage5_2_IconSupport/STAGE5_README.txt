Thadu APK Builder V1 - Stage 5
Native Print/PDF + Native Share

Base: Stage 4.1 Kotlin Fix.

Changes:
- Preserves Builder UI and Stage 4.1 Kotlin dependency fix.
- Generated Android apps expose AndroidShare.shareText().
- Generated Android apps expose AndroidShare.shareJpg().
- Generated Android apps expose AndroidShare.printCurrentPage().
- window.print() is bridged to Android PrintManager when running in APK.
- navigator.share() uses native text share for text-only shares, while file shares continue to use the WebView's original navigator.share when available. This preserves existing JPG share behavior.
- Browser preview behavior is preserved because the compatibility bridge only runs inside the generated Android WebView.
- Print uses the current WebView print document, so existing @media print rules in an HTML app can control what is printed.

Build:
Use .github/workflows/build-apk.yml with Java 17 and Gradle 8.7 as in Stage 4.


STAGE 5.1.1 HOTFIX: Fixed Android Print job-name compilation error by loading application label via getApplicationInfo().loadLabel(getPackageManager()).toString().
