The selected HTML/ZIP project will replace/populate this assets directory during generation.
