# Thadu APK Builder V1 — Stage 3 FIXED

The Builder UI is the root `index.html`.

The Android generated-app template is intentionally stored separately under:
`android-template/`

This prevents the Builder from opening the generated demo app instead of the
Builder UI.

Current Stage:
- Builder UI preserved
- HTML / ZIP picker
- App information
- WebView settings
- Permissions
- Project generator screen
- Separate Android project template
- FileProvider/ACTION_SEND architecture retained

Next:
- Native generation bridge that copies the selected HTML/ZIP into the
  Android template and applies App Name / Package / Version.
