<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Thadu APK Builder V1</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f4f7fb;color:#172033}
.app{max-width:720px;margin:auto;min-height:100vh}
header{padding:22px 18px 16px;background:linear-gradient(135deg,#173b72,#2866b5);color:white}
h1{margin:0;font-size:24px} header p{margin:6px 0 0;opacity:.88;font-size:13px}
main{padding:16px}
.card{background:white;border-radius:18px;padding:16px;margin-bottom:14px;box-shadow:0 5px 18px #0000000b}
.title{font-weight:800;font-size:17px;margin-bottom:12px}
label{display:block;font-size:13px;font-weight:700;margin:11px 0 6px}
input,select{width:100%;padding:13px;border:1px solid #d9e0ea;border-radius:12px;font-size:15px;background:#fff}
.filebox{border:2px dashed #b9c7da;border-radius:15px;padding:20px;text-align:center;background:#f8fbff}
.filebox input{border:0;padding:0;margin-top:10px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.switch{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #edf0f5}
.switch:last-child{border-bottom:0}
.switch small{display:block;color:#697386;margin-top:3px}
button{width:100%;border:0;border-radius:13px;padding:14px;font-weight:800;font-size:15px}
.primary{background:#1769d1;color:white}.secondary{background:#edf3fb;color:#174d91}
.preview{min-height:100px;border:1px solid #e1e6ef;border-radius:14px;padding:14px;background:#fafcff}
.status{font-size:13px;color:#526174;line-height:1.5}
.badge{display:inline-block;padding:5px 9px;border-radius:999px;background:#e8f2ff;color:#1769d1;font-size:11px;font-weight:800}
</style>
<script src="https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js"></script>
</head>
<body>
<div class="app">
<header>
  <h1>🛠️ Thadu APK Builder V1</h1>
  <p>HTML / ZIP → Android App • Phone Friendly</p>
</header>
<main>
<section class="card">
  <div class="title">① Project File</div>
  <div class="filebox">
    <div class="badge">HTML / ZIP</div>
    <label for="projectFile">Choose your app file</label>
    <input id="projectFile" type="file" accept=".html,.htm,.zip">
    <div id="fileStatus" class="status">No project selected.</div>
  </div>
</section>

<section class="card">
  <div class="title">② App Information</div>
  <label>App Name</label>
  <input id="appName" value="My Thadu App" maxlength="40">
  <div class="row">
    <div><label>Package Name</label><input id="packageName" value="com.thadu.myapp"></div>
    <div><label>Version</label><input id="version" value="1.0.0"></div>
  </div>
  <label>App Icon</label>
  <input id="iconFile" type="file" accept="image/png,image/jpeg">
</section>

<section class="card">
  <div class="title">③ WebView</div>
  <div class="switch"><div><b>JavaScript</b><small>Enable HTML/JS apps</small></div><input id="js" type="checkbox" checked></div>
  <div class="switch"><div><b>DOM Storage</b><small>localStorage / app data</small></div><input id="storage" type="checkbox" checked></div>
  <div class="switch"><div><b>Native File Share</b><small>JPG / Text → Android Share Sheet • Print / PDF</small></div><input id="nativeShare" type="checkbox" checked></div>
</section>

<section class="card">
  <div class="title">④ Permissions</div>
  <div class="row">
    <label><input type="checkbox" id="internet" checked> Internet</label>
    <label><input type="checkbox" id="camera"> Camera</label>
    <label><input type="checkbox" id="notify"> Notifications</label>
    <label><input type="checkbox" id="vibrate"> Vibration</label>
  </div>
</section>

<section class="card">
  <div class="title">⑤ Project Generator</div>
  <div class="preview">
    <b id="previewName">My Thadu App</b>
    <p class="status">Stage 5.2.1 fixes ZIP projects whose index.html is inside a folder. Launcher Icon + Native Share/Print/PDF are preserved.</p>
  </div>
  <br>
  <button class="primary" id="generateBtn">📦 Generate Android Project</button>
  <p id="status" class="status"></p>
</section>
</main>
<footer>Thadu APK Builder V1 • Stage 5.2.1 ZIP Index Fix + Icon</footer>

<script>
const $=id=>document.getElementById(id);
$('projectFile').addEventListener('change',()=>{
 const f=$('projectFile').files[0];
 $('fileStatus').textContent=f?`Selected: ${f.name} • ${(f.size/1024).toFixed(1)} KB`:'No project selected.';
});
$('appName').addEventListener('input',()=>{$('previewName').textContent=$('appName').value||'My Thadu App';});
$('generateBtn').addEventListener('click', async ()=>{
 const f=$('projectFile').files[0];
 if(!f){$('status').textContent='⚠️ Choose an HTML or ZIP project first.';return;}

 const name=($('appName').value||'My Thadu App').trim();
 const pkg=($('packageName').value||'com.thadu.myapp').trim().toLowerCase();
 const ver=($('version').value||'1.0.0').trim();
 const iconFile=$('iconFile').files[0]||null;

 if(!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg)){
   $('status').textContent='⚠️ Package Name မမှန်ပါ။ ဥပမာ com.thadu.myapp';
   return;
 }

 if(!window.JSZip){
   $('status').textContent='⚠️ ZIP engine မတင်ရသေးပါ။ Internet connection လိုပါတယ်။';
   return;
 }

 try{
   $('status').textContent='⏳ Android Project ကို generate လုပ်နေပါတယ်…';

   const z=new JSZip();

   // ---------- Optional launcher icon ----------
   let iconBytes=null, iconExt='png';
   if(iconFile){
     if(!/^image\/(png|jpeg)$/.test(iconFile.type)){
       $('status').textContent='⚠️ App Icon က PNG/JPG ဖြစ်ရပါမယ်။';
       return;
     }
     iconExt=iconFile.type==='image/jpeg'?'jpg':'png';
     iconBytes=await iconFile.arrayBuffer();
   }

   // ---------- Android project template ----------
   const gradle=`plugins { id 'com.android.application' version '8.6.1' apply false }`;

   const settings=`pluginManagement {
 repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
 repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
 repositories { google(); mavenCentral() }
}
rootProject.name="GeneratedThaduApp"
include(":app")`;

   const props=`org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true`;

   const appGradle=`plugins { id 'com.android.application' }
android {
 namespace '${pkg}'
 compileSdk 35
 defaultConfig {
  applicationId "${pkg}"
  minSdk 23
  targetSdk 35
  versionCode 1
  versionName "${ver}"
 }
}
configurations.configureEach {
 resolutionStrategy.force 'org.jetbrains.kotlin:kotlin-stdlib:1.8.22'
 exclude group: 'org.jetbrains.kotlin', module: 'kotlin-stdlib-jdk8'
}
dependencies {
 implementation 'androidx.appcompat:appcompat:1.7.0'
 implementation 'androidx.core:core:1.15.0'
}`;

   const manifest=`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
 <uses-permission android:name="android.permission.INTERNET"/>
 <application android:allowBackup="true" android:label="${escapeXml(name)}"
  android:supportsRtl="true" android:theme="@style/AppTheme"${iconFile?` android:icon="@drawable/app_icon"`:``}>
  <activity android:name=".MainActivity" android:exported="true">
   <intent-filter>
    <action android:name="android.intent.action.MAIN"/>
    <category android:name="android.intent.category.LAUNCHER"/>
   </intent-filter>
  </activity>
  <provider android:name="androidx.core.content.FileProvider"
   android:authorities="${pkg}.fileprovider"
   android:exported="false" android:grantUriPermissions="true">
   <meta-data android:name="android.support.FILE_PROVIDER_PATHS"
    android:resource="@xml/file_paths"/>
  </provider>
 </application>
</manifest>`;

   const styles=`<?xml version="1.0" encoding="utf-8"?>
<resources>
 <style name="AppTheme" parent="Theme.AppCompat.Light.NoActionBar">
  <item name="android:fontFamily">sans</item>
  <item name="android:colorAccent">#1769D1</item>
  <item name="android:navigationBarColor">#000000</item>
  <item name="android:statusBarColor">#173B72</item>
  <item name="android:windowLightStatusBar">false</item>
 </style>
</resources>`;

   const paths=`<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
 <cache-path name="shared_cache" path="shared/"/>
 <files-path name="shared_files" path="shared/"/>
</paths>`;

   const pkgPath=pkg.replace(/\./g,'/');
   const java=`package ${pkg};

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
 private WebView webView;

 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  webView=new WebView(this);
  setContentView(webView);
  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);
  webView.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){
    super.onPageFinished(view,url);
    installCompatibilityBridge(view);
   }
  });
  webView.addJavascriptInterface(new NativeBridge(),"AndroidShare");
  webView.loadUrl("file:///android_asset/index.html");
 }

 private void installCompatibilityBridge(WebView view){
  String js="javascript:(function(){"
    +"try{"
    +"window.__thaduNativePrint=window.print;"
    +"window.print=function(){if(window.AndroidShare&&AndroidShare.printCurrentPage){AndroidShare.printCurrentPage();}else{window.__thaduNativePrint();}};"
    +"var originalShare=(navigator.share?function(d){return navigator.share(d);}:null);"
    +"if(!navigator.__thaduNativeShareInstalled){"
    +"  var nativeShare=function(data){"
    +"    data=data||{};"
    +"    if(data.files&&data.files.length){"
    +"      if(originalShare){return originalShare(data);}"
    +"      return Promise.reject(new Error('File sharing is not available'));"
    +"    }"
    +"    if(window.AndroidShare&&AndroidShare.shareText){"
    +"      AndroidShare.shareText(data.title||document.title||'Share',data.text||'');"
    +"      return Promise.resolve();"
    +"    }"
    +"    if(originalShare){return originalShare(data);}"
    +"    return Promise.reject(new Error('Share is not available'));"
    +"  };"
    +"  try{Object.defineProperty(navigator,'share',{configurable:true,writable:true,value:nativeShare});}"
    +"  catch(e){try{navigator.share=nativeShare;}catch(e2){}}"
    +"  navigator.__thaduNativeShareInstalled=true;"
    +"}"
    +" }catch(e){}"
    +"})();";
  view.evaluateJavascript(js,null);
 }

 private class NativeBridge {
  @JavascriptInterface public void shareText(String title,String text){
   Intent i=new Intent(Intent.ACTION_SEND);
   i.setType("text/plain");
   i.putExtra(Intent.EXTRA_TITLE,title);
   i.putExtra(Intent.EXTRA_TEXT,text);
   startActivity(Intent.createChooser(i,title==null||title.isEmpty()?"Share":title));
  }
  @JavascriptInterface public void shareJpg(String base64,String name){
   try{
    byte[] data=Base64.decode(base64,Base64.DEFAULT);
    File dir=new File(getCacheDir(),"shared");
    if(!dir.exists()) dir.mkdirs();
    File f=new File(dir,(name==null||name.isEmpty())?"Thadu_Order.jpg":name);
    try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}
    Uri u=FileProvider.getUriForFile(MainActivity.this,
      getPackageName()+".fileprovider",f);
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("image/jpeg");
    i.putExtra(Intent.EXTRA_STREAM,u);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivity(Intent.createChooser(i,"Share JPG"));
   }catch(Exception e){
    Toast.makeText(MainActivity.this,e.toString(),Toast.LENGTH_LONG).show();
   }
  }
  @JavascriptInterface public void printCurrentPage(){
   runOnUiThread(new Runnable(){
    @Override public void run(){
     try{
      PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
      if(pm==null){Toast.makeText(MainActivity.this,"Print service မရနိုင်ပါ။",Toast.LENGTH_LONG).show();return;}
      String jobName=getApplicationInfo().loadLabel(getPackageManager()).toString()+" Print";
      PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter(jobName);
      pm.print(jobName,adapter,new PrintAttributes.Builder()
        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
        .build());
     }catch(Exception e){
      Toast.makeText(MainActivity.this,"Print မလုပ်နိုင်ပါ: "+e.getMessage(),Toast.LENGTH_LONG).show();
     }
    }
   });
  }
 }
}`;

   z.file('settings.gradle',settings);
   z.file('build.gradle',gradle);
   z.file('gradle.properties',props);
   z.file('app/build.gradle',appGradle);
   z.file('app/src/main/AndroidManifest.xml',manifest);
   z.file('app/src/main/res/values/styles.xml',styles);
   z.file('app/src/main/res/xml/file_paths.xml',paths);
   if(iconBytes){ z.file('app/src/main/res/drawable/app_icon.'+iconExt,new Uint8Array(iconBytes)); }
   z.file('app/src/main/java/'+pkgPath+'/MainActivity.java',java);

   // ---------- Project payload ----------
   if(f.name.toLowerCase().endsWith('.zip')){
     const input=await JSZip.loadAsync(f);
     let count=0;
     let foundIndex=false;
     let indexBytes=null;
     const jobs=[];
     input.forEach((path,entry)=>{
       if(entry.dir) return;
       const clean=path.replace(/^\/+/,'');
       if(!clean || clean.startsWith('__MACOSX/')) return;
       jobs.push(entry.async('uint8array').then(bytes=>{
         z.file('app/src/main/assets/'+clean,bytes);
         count++;
         const base=clean.split('/').pop().toLowerCase();
         if(base==='index.html' || base==='index.htm'){
           foundIndex=true;
           indexBytes=bytes;
         }
       }));
     });
     await Promise.all(jobs);
     // Android loads file:///android_asset/index.html from the asset root.
     // If the uploaded ZIP has a top-level folder, also place its index at the root.
     if(foundIndex && indexBytes){
       z.file('app/src/main/assets/index.html',indexBytes);
     }else{
       $('status').textContent='❌ ZIP ထဲမှာ index.html မတွေ့ပါ။ Project မထုတ်တော့ပါ။';
       return;
     }
   }else{
     const text=await f.text();
     z.file('app/src/main/assets/index.html',text);
   }

   z.file('.github/workflows/build-apk.yml', `name: Build Android APK

on:
  workflow_dispatch:

jobs:
  build-apk:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: Build debug APK
        run: gradle :app:assembleDebug --no-daemon

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: thadu-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
`);

   z.file('PROJECT_INFO.txt',
`Thadu APK Builder V1 - Generated Project
App Name: ${name}
Package: ${pkg}
Version: ${ver}
Native Share: FileProvider + ACTION_SEND
Payload: ${f.name}
`);

   const blob=await z.generateAsync({type:'blob'});
   const a=document.createElement('a');
   a.href=URL.createObjectURL(blob);
   a.download=name.replace(/[^a-z0-9]+/gi,'_')+'_AndroidProject.zip';
   document.body.appendChild(a);
   a.click();
   a.remove();
   setTimeout(()=>URL.revokeObjectURL(a.href),3000);

   $('status').textContent='✅ Android Project ZIP ထုတ်ပြီးပါပြီ။ GitHub Actions cloud-build workflow ပါထည့်ထားပါတယ်။ GitHub မှာ project တင်ပြီး Actions → Build Android APK → Run workflow လုပ်နိုင်ပါတယ်။';
 }catch(e){
   console.error(e);
   $('status').textContent='❌ Generate error: '+(e.message||e);
 }
});

function escapeXml(s){
 return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
  .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}
</script>
</body>
</html>