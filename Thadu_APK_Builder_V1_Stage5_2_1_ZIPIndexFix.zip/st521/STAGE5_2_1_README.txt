Thadu APK Builder V1 - Stage 5.2.1

Fix: ZIP projects whose index.html is inside a top-level folder now also get a root app/src/main/assets/index.html, matching the Android WebView load path file:///android_asset/index.html.

Preserves Stage 5.2 launcher App Icon support and Native Print/PDF, Text Share, JPG Share.
If a ZIP has no index.html/index.htm at all, generation stops instead of creating a broken APK.
