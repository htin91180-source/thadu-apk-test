package com.thadu.myapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  setContentView(w);
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);
  w.setWebViewClient(new WebViewClient());
  w.addJavascriptInterface(new NativeBridge(),"AndroidShare");
  w.loadUrl("file:///android_asset/index.html");
 }
 private class NativeBridge {
  @JavascriptInterface public void shareText(String title,String text){
   Intent i=new Intent(Intent.ACTION_SEND);
   i.setType("text/plain");
   i.putExtra(Intent.EXTRA_TITLE,title);
   i.putExtra(Intent.EXTRA_TEXT,text);
   startActivity(Intent.createChooser(i,title));
  }
  @JavascriptInterface public void shareJpg(String base64,String name){
   try{
    byte[] data=Base64.decode(base64,Base64.DEFAULT);
    File dir=new File(getCacheDir(),"shared");
    if(!dir.exists()) dir.mkdirs();
    File f=new File(dir,(name==null||name.isEmpty())?"Thadu_Order.jpg":name);
    try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}
    Uri u=FileProvider.getUriForFile(MainActivity.this,
      getPackageName()+".fileprovider",f);
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("image/jpeg");
    i.putExtra(Intent.EXTRA_STREAM,u);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivity(Intent.createChooser(i,"Share JPG"));
   }catch(Exception e){
    Toast.makeText(MainActivity.this,e.toString(),Toast.LENGTH_LONG).show();
   }
  }
 }
}