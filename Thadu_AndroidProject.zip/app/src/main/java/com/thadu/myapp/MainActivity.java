package com.thadu.myapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Handler;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
 private WebView webView;

 @Override public void onBackPressed(){
  if(BACK_WEBVIEW && webView!=null && webView.canGoBack()){ webView.goBack(); return; }
  super.onBackPressed();
 }

 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  if(HIDE_STATUS_BAR){ getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN, android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN); }
  if(FULLSCREEN){ getWindow().getDecorView().setSystemUiVisibility(
    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
  if(ENABLE_SPLASH){ showSplash(); } else { initWebView(); }
 }

 private void showSplash(){
  FrameLayout root=new FrameLayout(this);
  root.setBackgroundColor(Color.parseColor(SPLASH_BG));
  LinearLayoutCompatShim box=new LinearLayoutCompatShim(this);
  box.setGravity(Gravity.CENTER);
  box.setOrientation(android.widget.LinearLayout.VERTICAL);
  int pad=(int)(24*getResources().getDisplayMetrics().density);
  box.setPadding(pad,pad,pad,pad);
  if(HAS_ICON){
   ImageView iv=new ImageView(this);
   int size=(int)(96*getResources().getDisplayMetrics().density);
   FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(size,size);
   ip.gravity=Gravity.CENTER_HORIZONTAL;
   iv.setLayoutParams(ip);
   int id=getResources().getIdentifier("app_icon","drawable",getPackageName());
   if(id!=0) iv.setImageResource(id);
   iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
   box.addView(iv);
  }
  TextView tv=new TextView(this);
  tv.setText(APP_NAME);
  tv.setTextColor(Color.WHITE);
  tv.setTextSize(22);
  tv.setGravity(Gravity.CENTER);
  tv.setTypeface(null,android.graphics.Typeface.BOLD);
  tv.setPadding(0,(int)(14*getResources().getDisplayMetrics().density),0,0);
  box.addView(tv,new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
  root.addView(box,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
  setContentView(root);
  new Handler().postDelayed(new Runnable(){ @Override public void run(){ initWebView(); } },SPLASH_DURATION);
 }

 private void initWebView(){
  webView=new WebView(this);
  setContentView(webView);
  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);
  webView.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){
    super.onPageFinished(view,url);
    installCompatibilityBridge(view);
   }
  });
  webView.addJavascriptInterface(new NativeBridge(),"AndroidShare");
  requestSelectedPermissions();
  webView.loadUrl("file:///android_asset/index.html");
 }

 // Tiny LinearLayout helper keeps generated Java self-contained.
 private static class LinearLayoutCompatShim extends android.widget.LinearLayout {
  LinearLayoutCompatShim(Context c){ super(c); }
 }

 private void requestSelectedPermissions(){
  java.util.ArrayList<String> req=new java.util.ArrayList<>();
  if(WANT_CAMERA && android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.CAMERA)!=android.content.pm.PackageManager.PERMISSION_GRANTED) req.add(android.Manifest.permission.CAMERA);
  if(WANT_MICROPHONE && android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED) req.add(android.Manifest.permission.RECORD_AUDIO);
  if(WANT_NOTIFY && android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED) req.add("android.permission.POST_NOTIFICATIONS");
  if((WANT_PHOTOS || WANT_VIDEO) && android.os.Build.VERSION.SDK_INT>=33){
   if(WANT_PHOTOS && checkSelfPermission("android.permission.READ_MEDIA_IMAGES")!=android.content.pm.PackageManager.PERMISSION_GRANTED) req.add("android.permission.READ_MEDIA_IMAGES");
   if(WANT_VIDEO && checkSelfPermission("android.permission.READ_MEDIA_VIDEO")!=android.content.pm.PackageManager.PERMISSION_GRANTED) req.add("android.permission.READ_MEDIA_VIDEO");
  } else if((WANT_PHOTOS || WANT_VIDEO) && android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
   req.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
  }
  if(!req.isEmpty()) requestPermissions(req.toArray(new String[0]),9001);
 }

 private static final boolean WANT_CAMERA=true;
 private static final boolean WANT_NOTIFY=true;
 private static final boolean WANT_PHOTOS=true;
 private static final boolean WANT_VIDEO=true;
 private static final boolean WANT_MICROPHONE=true;
 private static final boolean FULLSCREEN=true;
 private static final boolean HIDE_STATUS_BAR=false;
 private static final boolean BACK_WEBVIEW=true;
 private static final boolean ENABLE_SPLASH=true;
 private static final int SPLASH_DURATION=1500;
 private static final boolean HAS_ICON=true;
 private static final String APP_NAME="Thadu";
 private static final String SPLASH_BG="#000000";

 private void installCompatibilityBridge(WebView view){
  String js="javascript:(function(){"
    +"try{"
    +"window.__thaduNativePrint=window.print;"
    +"window.print=function(){if(window.AndroidShare&&AndroidShare.printCurrentPage){AndroidShare.printCurrentPage();}else{window.__thaduNativePrint();}};"
    +"var originalShareFn=(navigator.share?navigator.share.bind(navigator):null);"
    +"var originalCanShare=(navigator.canShare?navigator.canShare.bind(navigator):null);"
    +"if(!navigator.__thaduNativeShareInstalled){"
    +"  var nativeShare=function(data){"
    +"    data=data||{};"
    +"    if(data.files&&data.files.length){"
    +"      if(window.AndroidShare&&AndroidShare.shareJpg){"
    +"        var file=data.files[0];"
    +"        if(!file||!file.arrayBuffer){return Promise.reject(new Error('File sharing is not available'));}"
    +"        return file.arrayBuffer().then(function(buf){"
    +"          var bytes=new Uint8Array(buf),bin='';"
    +"          for(var i=0;i<bytes.length;i+=8192){bin+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+8192,bytes.length)));}"
    +"          AndroidShare.shareJpg(btoa(bin),file.name||'Thadu_Order.jpg');"
    +"        });"
    +"      }"
    +"      if(originalShareFn){return originalShareFn(data);}"
    +"      return Promise.reject(new Error('File sharing is not available'));"
    +"    }"
    +"    if(window.AndroidShare&&AndroidShare.shareText){"
    +"      AndroidShare.shareText(data.title||document.title||'Share',data.text||'');"
    +"      return Promise.resolve();"
    +"    }"
    +"    if(originalShareFn){return originalShareFn(data);}"
    +"    return Promise.reject(new Error('Share is not available'));"
    +"  };"
    +"  try{Object.defineProperty(navigator,'share',{configurable:true,writable:true,value:nativeShare});}"
    +"  catch(e){try{navigator.share=nativeShare;}catch(e2){}}"
    +"  if(window.AndroidShare&&AndroidShare.shareJpg){"
    +"    try{Object.defineProperty(navigator,'canShare',{configurable:true,writable:true,value:function(data){return !!(data&&data.files&&data.files.length);}});}"
    +"    catch(e3){try{navigator.canShare=function(data){return !!(data&&data.files&&data.files.length);};}catch(e4){}}"
    +"  } else if(originalCanShare){}"
    +"  navigator.__thaduNativeShareInstalled=true;"
    +"}"
    +" }catch(e){}"
    +"})();";
  view.evaluateJavascript(js,null);
 }

 private class NativeBridge {
  @JavascriptInterface public void shareText(String title,String text){
   Intent i=new Intent(Intent.ACTION_SEND);
   i.setType("text/plain");
   i.putExtra(Intent.EXTRA_TITLE,title);
   i.putExtra(Intent.EXTRA_TEXT,text);
   startActivity(Intent.createChooser(i,title==null||title.isEmpty()?"Share":title));
  }
  @JavascriptInterface public void shareJpg(String base64,String name){
   try{
    byte[] data=Base64.decode(base64,Base64.DEFAULT);
    File dir=new File(getCacheDir(),"shared");
    if(!dir.exists()) dir.mkdirs();
    File f=new File(dir,(name==null||name.isEmpty())?"Thadu_Order.jpg":name);
    try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}
    Uri u=FileProvider.getUriForFile(MainActivity.this,
      getPackageName()+".fileprovider",f);
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("image/jpeg");
    i.putExtra(Intent.EXTRA_STREAM,u);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivity(Intent.createChooser(i,"Share JPG"));
   }catch(Exception e){
    Toast.makeText(MainActivity.this,e.toString(),Toast.LENGTH_LONG).show();
   }
  }
  @JavascriptInterface public void printCurrentPage(){
   runOnUiThread(new Runnable(){
    @Override public void run(){
     try{
      PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
      if(pm==null){Toast.makeText(MainActivity.this,"Print service မရနိုင်ပါ။",Toast.LENGTH_LONG).show();return;}
      String jobName=getApplicationInfo().loadLabel(getPackageManager()).toString()+" Print";
      PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter(jobName);
      pm.print(jobName,adapter,new PrintAttributes.Builder()
        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
        .build());
     }catch(Exception e){
      Toast.makeText(MainActivity.this,"Print မလုပ်နိုင်ပါ: "+e.getMessage(),Toast.LENGTH_LONG).show();
     }
    }
   });
  }
 }
}