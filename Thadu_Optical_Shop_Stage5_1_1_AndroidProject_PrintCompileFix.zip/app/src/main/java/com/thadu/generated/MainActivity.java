package com.thadu.generated;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
 private WebView webView;

 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  webView=new WebView(this);
  setContentView(webView);

  WebSettings s=webView.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);

  webView.setWebViewClient(new WebViewClient(){
   @Override public void onPageFinished(WebView view,String url){
    super.onPageFinished(view,url);
    installCompatibilityBridge(view);
   }
  });

  webView.addJavascriptInterface(new NativeBridge(),"AndroidShare");
  webView.loadUrl("file:///android_asset/index.html");
 }

 private void installCompatibilityBridge(WebView view){
  String js="javascript:(function(){"
    +"try{"
    +"window.__thaduNativePrint=window.print;"
    +"window.print=function(){if(window.AndroidShare&&AndroidShare.printCurrentPage){AndroidShare.printCurrentPage();}else{window.__thaduNativePrint();}};"
    +"var originalShareFn=(navigator.share?navigator.share.bind(navigator):null);"
    +"if(!navigator.__thaduNativeShareInstalled){"
    +"  var nativeShare=function(data){"
    +"    data=data||{};"
    +"    if(data.files&&data.files.length){"
    +"      if(originalShareFn){return originalShareFn(data);}"
    +"      return Promise.reject(new Error('File sharing is not available'));"
    +"    }"
    +"    if(window.AndroidShare&&AndroidShare.shareText){"
    +"      AndroidShare.shareText(data.title||document.title||'Share',data.text||'');"
    +"      return Promise.resolve();"
    +"    }"
    +"    if(originalShareFn){return originalShareFn(data);}"
    +"    return Promise.reject(new Error('Share is not available'));"
    +"  };"
    +"  try{Object.defineProperty(navigator,'share',{configurable:true,writable:true,value:nativeShare});}"
    +"  catch(e){try{navigator.share=nativeShare;}catch(e2){}}"
    +"  navigator.__thaduNativeShareInstalled=true;"
    +"}"
    +" }catch(e){}"
    +"})();";
  view.evaluateJavascript(js,null);
 }

 private class NativeBridge {
  @JavascriptInterface public void shareText(String title,String text){
   Intent i=new Intent(Intent.ACTION_SEND);
   i.setType("text/plain");
   i.putExtra(Intent.EXTRA_TITLE,title);
   i.putExtra(Intent.EXTRA_TEXT,text);
   startActivity(Intent.createChooser(i,title==null||title.isEmpty()?"Share":title));
  }

  @JavascriptInterface public void shareJpg(String base64,String name){
   try{
    byte[] data=Base64.decode(base64,Base64.DEFAULT);
    File dir=new File(getCacheDir(),"shared");
    if(!dir.exists()) dir.mkdirs();
    File f=new File(dir,(name==null||name.isEmpty())?"Thadu_Order.jpg":name);
    try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}
    Uri u=FileProvider.getUriForFile(MainActivity.this,
      getPackageName()+".fileprovider",f);
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("image/jpeg");
    i.putExtra(Intent.EXTRA_STREAM,u);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    startActivity(Intent.createChooser(i,"Share JPG"));
   }catch(Exception e){
    Toast.makeText(MainActivity.this,e.toString(),Toast.LENGTH_LONG).show();
   }
  }

  @JavascriptInterface public void printCurrentPage(){
   runOnUiThread(new Runnable(){
    @Override public void run(){
     try{
      PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
      if(pm==null){Toast.makeText(MainActivity.this,"Print service မရနိုင်ပါ။",Toast.LENGTH_LONG).show();return;}
      String jobName=getApplicationInfo().loadLabel(getPackageManager()).toString()+" Print";
      PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter(jobName);
      pm.print(jobName,adapter,new PrintAttributes.Builder()
        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
        .build());
     }catch(Exception e){
      Toast.makeText(MainActivity.this,"Print မလုပ်နိုင်ပါ: "+e.getMessage(),Toast.LENGTH_LONG).show();
     }
    }
   });
  }
 }
}
